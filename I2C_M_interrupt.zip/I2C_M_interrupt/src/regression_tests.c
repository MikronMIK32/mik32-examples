
#include "common.h"
#include "i2c_irq_common.h"


int main()
{
    TestI2cIrq(I2C_0, EPIC_I2C_0_INDEX);
}


